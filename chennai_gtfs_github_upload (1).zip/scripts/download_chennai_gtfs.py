"""
Download and extract the Chennai MTC GTFS dataset.

Run from the project root:
    python scripts/download_chennai_gtfs.py
"""
from pathlib import Path
from urllib.request import urlretrieve
from zipfile import ZipFile
import urllib.error

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data" / "chennai_mtc_gtfs"
ZIP_PATH = PROJECT_ROOT / "data" / "mtc-gtfs.zip"
SOURCE_URL = (
    "https://github.com/ungalsoththu/ChennaiGTFS/"
    "raw/refs/heads/main/data/mtc-gtfs.zip"
)

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ZIP_PATH.parent.mkdir(parents=True, exist_ok=True)

    if not ZIP_PATH.exists():
        print("Downloading Chennai MTC GTFS archive...")
        try:
            urlretrieve(SOURCE_URL, ZIP_PATH)
        except (urllib.error.URLError, OSError) as exc:
            if ZIP_PATH.exists():
                ZIP_PATH.unlink()
            raise SystemExit(
                f"Download failed: {exc}\n"
                f"Try downloading manually from: {SOURCE_URL}"
            )

    print(f"Extracting {ZIP_PATH.name} to {DATA_DIR}...")
    with ZipFile(ZIP_PATH, "r") as archive:
        archive.extractall(DATA_DIR)

    tables = sorted(
        p.name for p in DATA_DIR.rglob("*")
        if p.is_file() and p.suffix.lower() in {".txt", ".csv"}
    )
    print(f"Done. Found {len(tables)} CSV-style table(s):")
    for name in tables:
        print(f" - {name}")
    print("Note: this GTFS feed does not include actual passenger counts per route.")

if __name__ == "__main__":
    main()
