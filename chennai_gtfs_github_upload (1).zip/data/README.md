# Chennai MTC GTFS dataset

## Source
- Upstream repository: https://github.com/ungalsoththu/ChennaiGTFS
- Direct archive: https://github.com/ungalsoththu/ChennaiGTFS/raw/refs/heads/main/data/mtc-gtfs.zip

## Download the actual data
From the project root, run:

```bash
python scripts/download_chennai_gtfs.py
```

The script downloads the source archive and extracts its GTFS text tables into
`data/chennai_mtc_gtfs/`. GTFS tables are comma-separated text files even when
their extension is `.txt`; they can be loaded with pandas:

```python
import pandas as pd

routes = pd.read_csv("data/chennai_mtc_gtfs/routes.txt")
stops = pd.read_csv("data/chennai_mtc_gtfs/stops.txt")
trips = pd.read_csv("data/chennai_mtc_gtfs/trips.txt")
stop_times = pd.read_csv("data/chennai_mtc_gtfs/stop_times.txt")
```

## Important limitation
This GTFS dataset supports route, stop, trip, and timetable analysis. It does
**not** provide verified actual passenger counts for every bus route. For
ridership-based optimization, add a separately sourced ridership dataset or
clearly label generated demand values as simulated.

Check the upstream source's current data notes and terms before redistributing
downloaded source files.
